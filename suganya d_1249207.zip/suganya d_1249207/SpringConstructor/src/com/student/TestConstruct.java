package com.student;



import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;  
public class TestConstruct 
{
public static void main(String[] args)
{
	Resource r=new ClassPathResource("web.xml");  
    BeanFactory factory=new XmlBeanFactory(r);  
       
     Student s=(Student)factory.getBean("stu");  
     s.display();  
}
}
