package com.student;

public class Student 
{
int id;
String name;
int cls;
public Student(int id, String name, int cls) 
{
	super();
	this.id = id;
	this.name = name;
	this.cls = cls;
}

public void display() 
{
	System.out.println("ID:" +" "+id+" "+"Name:"+" "+name+" "+"Standard:"+" "+cls);
}

	


}
