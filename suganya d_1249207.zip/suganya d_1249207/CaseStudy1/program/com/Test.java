package com;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Test 
{
	

public static void main(String[] args)
{
	HashMap<Integer,Connections> map=new HashMap<Integer,Connections>();
	
	Connections c1=new Connections(123,"suganya");
	Connections c2=new Connections(124,"sashu");
	Connections c3=new Connections(125,"baby");
	Connections c4=new Connections(126,"dev");
	
	map.put(1,c1);
	map.put(2, c2);
	map.put(3, c3);
	map.put(4, c4);
	for(Map.Entry<Integer,Connections> entry:map.entrySet())
	{
	 int key=entry.getKey();
	 Connections c=entry.getValue();
	 System.out.println("Details of the Student "+key);
	 System.out.println(" "+c);
	 
	}
	
	System.out.println("Before Removing:");
	System.out.println(map);
	System.out.println("Size of Map: " + map.size());
	map.remove(4);
	System.out.println("After Removing:");
	System.out.println(map);
	System.out.println("Size of Map: " + map.size());
	
	Scanner sc=new Scanner(System.in);  
    System.out.println("Enter your id:"); 
    int key=sc.nextInt(); 
	if(map.containsKey(key))
	{
		System.out.println("The hashmap contains value");
		System.out.println(map.get(key)); 
	}
	else 
	{
		System.out.println("The hashmap does not contains value");
	}



	}
}
