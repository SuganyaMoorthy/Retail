package com.list;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Copying 
{
	public static void main(String[] args)
	{
		LinkedList<String> a = new LinkedList<String>(); 
		a.add("sugan");
		a.add("suha");
		a.add("mom");
		a.add("dad");
		System.out.println("The LinkedList is:");
		Iterator<String> itr=a.iterator();  
		while(itr.hasNext())
		{  
		 System.out.println(itr.next());  
		}
		System.out.println("List size:" + a.size());
		ArrayList<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        a.addAll(list);
        System.out.println("After adding"+""+a);
        System.out.println("The name is contains?:"+a.contains("suha"));
        System.out.println("The Index of the name:"+a.indexOf("suha"));
        
	
}
}
