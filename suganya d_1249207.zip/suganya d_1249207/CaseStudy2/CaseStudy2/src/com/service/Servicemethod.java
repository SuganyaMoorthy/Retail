package com.service;

import com.DAO.DAOOperations;
import com.pojo.Registration;

public class Servicemethod{

	public static int addRegistration(Registration reg)
	{
		return DAOOperations.addRegistration(reg);
	}
	
	public static int login(String id,String pwd)
	{
		return DAOOperations.login(id,pwd);
	}

}
