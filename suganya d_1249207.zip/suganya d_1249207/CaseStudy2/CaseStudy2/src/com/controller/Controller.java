package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.DAOOperations;
import com.pojo.Registration;
import com.service.*;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("CONtoll");
		String action = request.getParameter("action");
		if("login".equals(action))
		{
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			
			int i=Servicemethod.login(id, pwd);
			HttpSession session=request.getSession();  
	        session.setAttribute("id",id);  
			System.out.println("dfgtdfgxdfg");

			if(i==1)
			{
				request.setAttribute(id,"id");
				RequestDispatcher rd = request.getRequestDispatcher("sucess.jsp");
				
		System.out.println("IN LOGIN CRTL"+id);
				rd.forward(request,response);
			}
			else
				if(i == -1)
				{

					RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
					rd.forward(request,response);
				}
		}

		else if("registration".equals(action))
		{
			System.out.println("DFGSG");
			Registration reg = new Registration();
			reg.setUserid(request.getParameter("id"));
			reg.setPassword(request.getParameter("pwd"));
			reg.setConfirmPassword(request.getParameter("cp"));
			reg.setLang(request.getParameter("PL"));
			reg.setFirstName(request.getParameter("fname"));
			reg.setLastName(request.getParameter("last"));
			reg.setGender(request.getParameter("gender"));
			reg.setMaritalStatus(request.getParameter("ms"));
			
			String date=request.getParameter("DOB");
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-M-dd");
			java.util.Date date1=null;;
			try {
				date1 = sdf.parse(date);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			java.sql.Date sqlDateto = new java.sql.Date(date1.getTime());
			reg.setDOB(sqlDateto);


			//		reg.setDOB(DateParse.getDate(request.getParameter("DOB")));


			
			reg.setEmailid(request.getParameter("emailid"));
			
			
			reg.setMobile(Long.parseLong(request.getParameter("mobile")));


			
			int i=Servicemethod.addRegistration(reg);
			System.out.println(i);

			if(i==0)
			{
				RequestDispatcher rd = request.getRequestDispatcher("failurePage.jsp");
				rd.forward(request,response);
			}
			else
			{
				RequestDispatcher rd = request.getRequestDispatcher("RegisterSuccess.jsp");
				rd.forward(request,response);
			}


		}
		else if("viewdetails".equals(action))
		{
			System.out.println("VIES DDD");
				RequestDispatcher rd = request.getRequestDispatcher("ViewDetails.jsp");
				
				rd.forward(request,response);
			
		}


	}

}
